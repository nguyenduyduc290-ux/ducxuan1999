---
name: Precision Fleet
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#45464c'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#575e70'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#141b2b'
  on-primary-container: '#7d8497'
  inverse-primary: '#c0c6db'
  secondary: '#555f70'
  on-secondary: '#ffffff'
  secondary-container: '#d6e0f4'
  on-secondary-container: '#596374'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#00174b'
  on-tertiary-container: '#497cff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dce2f7'
  primary-fixed-dim: '#c0c6db'
  on-primary-fixed: '#141b2b'
  on-primary-fixed-variant: '#404758'
  secondary-fixed: '#d9e3f7'
  secondary-fixed-dim: '#bdc7db'
  on-secondary-fixed: '#121c2a'
  on-secondary-fixed-variant: '#3d4757'
  tertiary-fixed: '#dbe1ff'
  tertiary-fixed-dim: '#b4c5ff'
  on-tertiary-fixed: '#00174b'
  on-tertiary-fixed-variant: '#003ea8'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 3.5rem
    fontWeight: '700'
    lineHeight: 4rem
    letterSpacing: -0.025em
  display-lg-mobile:
    fontFamily: Inter
    fontSize: 2.25rem
    fontWeight: '700'
    lineHeight: 2.75rem
    letterSpacing: -0.02em
  headline-xl:
    fontFamily: Inter
    fontSize: 2.25rem
    fontWeight: '700'
    lineHeight: 2.75rem
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Inter
    fontSize: 1.75rem
    fontWeight: '700'
    lineHeight: 2.25rem
    letterSpacing: -0.015em
  headline-lg:
    fontFamily: Inter
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: 2rem
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Inter
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.75rem
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: 1.75rem
    letterSpacing: -0.005em
  body-md:
    fontFamily: Inter
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.5rem
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.25rem
    letterSpacing: 0em
  label-lg:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: '600'
    lineHeight: 1.25rem
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: 1rem
    letterSpacing: 0.02em
  label-caps:
    fontFamily: Inter
    fontSize: 0.6875rem
    fontWeight: '700'
    lineHeight: 0.875rem
    letterSpacing: 0.05em
  metric-val:
    fontFamily: Inter
    fontSize: 2rem
    fontWeight: '700'
    lineHeight: 2.25rem
    letterSpacing: -0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system targets high-net-worth individual sellers, luxury auto brokers, and institutional fleet directors. The core brand pillars are **uncompromising precision, institutional trust, and high-velocity performance**. 

The aesthetic is Modern Corporate SaaS fused with high-end automotive industrial design:
- **Structural Integrity:** Heavy reliance on high contrast, confident vertical rhythms, and purposeful data density rather than decorative fluff.
- **Atmosphere:** Cool, disciplined, and executive. The white-glove experience is communicated through crisp line weights, clean typographic hierarchy, micro-interactions with immediate mechanical responsiveness, and expansive whitespace balancing information-dense fleet telemetry.
- **Emotion:** Transmits control, clarity, security, and prestige. It avoids consumer clutter in favor of an authoritative cockpit experience.

## Colors

The palette balances authoritative deep values with electric precision accents:

- **Primary (`#111827`):** Deep Navy/Charcoal. Anchors dominant navigation bars, primary CTA buttons, page titles, and essential high-contrast metric values.
- **Secondary (`#374151`):** Deep Slate. Deployed for secondary button borders, active icons, table section headers, and sub-navigation controls.
- **Tertiary / Accent (`#2563EB` & `#1D4ED8` on hover):** Electric Automotive Blue. Reserved for primary interactive accents, focus rings, interactive states, telemetry line charts, and active selection toggles.
- **Neutral Canvas (`#F8FAFC`):** Cool Crisp Slate. Provides a high-clarity backdrop that allows pure white card modules (`#FFFFFF`) and hairline borders (`#E2E8F0`) to establish spatial separation.
- **Supporting Semantic Signals:**
  - Success: `#16A34A` (Emerald) for healthy fleet statuses, completed transfers, and positive yield deltas.
  - Warning: `#F59E0B` (Amber) for scheduled maintenance triggers and escrow inspections.
  - Danger: `#DC2626` (Rose Red) for telemetry alarms, critical compliance flags, and disconnected asset monitors.
  - Muted Text: `#64748B` (Slate Muted) for auxiliary meta labels, timestamps, and table headers.

## Typography

Inter serves as the sole typographic foundation across all breakpoints to ensure extreme technical clarity and structural uniformity.

- **Tabular Figures:** Always apply `font-feature-settings: "tnum" 1, "cv02" 1, "cv03" 1, "cv04" 1` across data grids, telemetry displays, asset mileage tallies, and financial ledgers to prevent column jittering.
- **Case Rhythms:** Utilize `label-caps` with uppercase transformations strictly for system statuses, column headers, vehicle VIN metadata, and sub-labels.
- **Hierarchy Enforcements:** High numerical contrast between `metric-val` and adjacent change indicators ensures effortless executive scanning.

## Layout & Spacing

The layout is built on a responsive 12-column grid prioritizing density, data clarity, and scalable enterprise fleet dashboards.

- **Desktop (>= 1280px):** Fixed or max-contained fluid grid with 12 columns, `1.5rem` gutters, and `2rem` outer margins. Left navigation shell is fixed at `16rem` width with the main stage expanding dynamically.
- **Tablet (768px - 1279px):** 8-column layout with `1.25rem` gutters and `1.5rem` margins. Sidebars collapse to icon-only rails (`4.5rem` width). Multi-card metric rails condense into 2x2 grids.
- **Mobile (< 768px):** 4-column layout with `1rem` gutters and `1rem` outer canvas padding. Metrics stack vertically or convert to horizontal snap-scroll carousels. Data tables default to high-priority summary cards with drawer triggers.
- **Spacing Cadence:** Derived strictly from an 8-point foundation (`0.25rem`, `0.5rem`, `1rem`, `1.5rem`, `2rem`), maintaining exact vertical alignment across nested dashboard cards.

## Elevation & Depth

This system avoids heavy drop shadows, relying instead on architectural border hierarchy and low-contrast ambient diffuse elevation to convey depth.

- **Base Layer (Ground):** `#F8FAFC` canvas. Flat, matte, non-distracting.
- **Level 1 (Card & Module Layer):** `#FFFFFF` surfaces bounded by a structural hairline border (`1px solid #E2E8F0`). Elevation is reinforced via a diffuse low-opacity shadow: `0 1px 3px 0 rgba(17, 24, 39, 0.05), 0 1px 2px -1px rgba(17, 24, 39, 0.03)`.
- **Level 2 (Dropdowns, Popovers & Hovered Cards):** Hairline border transitions to `#CBD5E1`. Shadow deepens to: `0 10px 15px -3px rgba(17, 24, 39, 0.08), 0 4px 6px -4px rgba(17, 24, 39, 0.03)`.
- **Level 3 (Modals & Fleet Drawers):** Backdrop overlay uses `#111827` at 50% opacity with a `4px` blur. Floating surfaces carry: `0 20px 25px -5px rgba(17, 24, 39, 0.12), 0 8px 10px -6px rgba(17, 24, 39, 0.05)`.
- **Focus Rings:** Non-inset `2px` ring in `#2563EB` separated from elements by a `2px` pure white gap.

## Shapes

The design uses balanced rounding to project engineered precision while remaining contemporary and approachable:

- **Containers & Structural Cards:** Standardize on `rounded-xl` (`1.5rem` or `24px` on top-level shells; internal nested sub-cards use `1rem` / `16px`).
- **Interactive Controls:** Standard buttons, input fields, dropdown toggles, and select menus utilize `rounded-lg` (`0.5rem` / `8px`) for a tailored, instrument-like feel.
- **Pills & Chips:** Status indicators, tags, and small pill buttons utilize full-radii (`9999px`) to visually contrast against square-aligned data tables and analytic grids.
- **Images:** Car thumbnails and showroom media strictly conform to `rounded-lg` with subtle `1px inset` border overlays to preserve edge definition against white backgrounds.

## Components

### Buttons
- **Primary:** `#111827` background, `#FFFFFF` text, `rounded-lg` border radius, `0.625rem 1.25rem` padding. Hover: `#1F2937`. Active: `#030712`.
- **Accent (High Priority):** `#2563EB` background, `#FFFFFF` text. Hover: `#1D4ED8`.
- **Secondary / Outline:** Background transparent, `#E2E8F0` border, `#111827` text. Hover: `#F8FAFC` background with `#CBD5E1` border.
- **Destructive:** `#DC2626` background, `#FFFFFF` text. Hover: `#B91C1C`.

### Cards & Metric Modules
- **Metric Cards:** `#FFFFFF` background, `rounded-xl`, `1px solid #E2E8F0`, padded at `1.5rem`. Layout: Upper row features muted uppercase category label (`label-caps`) paired with a micro status badge; middle row hosts the large bold metric (`metric-val`); bottom row hosts delta badge (e.g. `+12.4% vs last mo` in `#16A34A`) and micro sparkline or secondary fleet subtitle.
- **Showroom Listing Cards:** Split composition. Top contains a 16:9 vehicle imagery module with inset badge for availability; bottom section provides specs (mileage, engine, trim) aligned in a compact tabular grid with a terminal primary action row.

### Tables & Data Grids
- **Container:** Wrapped in a `rounded-xl` card with hairline `#E2E8F0` external boundary.
- **Table Header:** `#F8FAFC` background, `0.75rem 1rem` cell padding. Text is `label-caps` in `#64748B`.
- **Rows:** White alternating with `#FFFFFF`, subtle hover background `#F8FAFC`. Bottom cell border `1px solid #F1F5F9`.
- **Numeric Cells:** Monospaced/tabular alignment (`text-right`).

### Badges & Status Chips
- **Structure:** `rounded-full`, padding `0.25rem 0.625rem`, font `label-md`.
- **Active / Available:** `#DCFCE7` background, `#15803D` text, leading `6px` solid emerald indicator dot.
- **In Transit / Reserved:** `#DBEAFE` background, `#1D4ED8` text, leading electric blue dot.
- **Maintenance / Pending:** `#FEF3C7` background, `#B45309` text, leading amber dot.
- **Decommissioned / Alert:** `#FEE2E2` background, `#B91C1C` text, leading red dot.

### Inputs & Controls
- **Text Inputs & Selects:** Height `2.625rem`, `rounded-lg`, border `1px solid #E2E8F0`, placeholder `#94A3B8`, text `#111827`. Focus: Border `#2563EB`, ring `2px solid rgba(37, 99, 235, 0.15)`.
- **Checkboxes & Radios:** `rounded-md` (checkbox) or `rounded-full` (radio), border `1.5px solid #CBD5E1`. Checked state: `#2563EB` fill with clean white interior glyph.

### Specialized Fleet Components
- **Telemetry Sparklines:** Hairline 1.5px paths using `#2563EB` with subtle linear gradient fading into transparent neutral.
- **VIN Display Pill:** Monospace font tracking (`0.05em`), `#F1F5F9` background, `#374151` foreground, copy-to-clipboard micro interaction.